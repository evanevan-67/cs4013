import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class Readcsv {
	public static String[][] tablebuilder(String[] args) {
        
		String path = "C:\\Users\\e_hawkes\\OneDrive - Modular Automation\\Desktop\\CS4013 project\\CS Charity shop project.csv";
		String line;
		String[][] Itemlists = new String[10][6];
	try {
		BufferedReader br = new BufferedReader(new FileReader(path));
		
                String[] Titles         = new String[7];
                String[] UnderwearData  = new String[7];
                String[] ShirtData      = new String[7];
                String[] JeansData      = new String[7];
                String[] CapData        = new String[7];
                String[] HeadphonesData = new String[7];
                String[] RunnersData    = new String[7];
                String[] SocksData      = new String[7];
                String[] ScarfData      = new String[7];
                String[] GlovesData     = new String[7];
                String[] BandanaData    = new String[7];
                
		while((line = br.readLine()) != null) {
			String[] values = line.split(",");
                        //System.out.println("Stock: " + values[0] +",  Items Intake:  " + values[1] +",  In Stock: " + values[2] +",  Price: " + values[3] +",  Total Sales: " + values[4] +",  On Hire: "+ values[5] + ",  ItemCode: " + values[6]);
		
        switch(values[0]) {
          case "Stock" -> Titles = values;
          case "underwear" -> UnderwearData = values;
          case "shirt" -> ShirtData = values;
          case "jeans" -> JeansData = values;
          case "cap" -> CapData = values;
          case "Headphones" -> HeadphonesData = values;
          case "runners" -> RunnersData = values;
          case "socks" -> SocksData = values;
          case "scarf" -> ScarfData = values;
          case "gloves" -> GlovesData = values;
          case "bandana" -> BandanaData = values;
          default ->            {
                        }
}
                    // code block
        String[][] ItemTableArray = {Titles, UnderwearData, ShirtData, JeansData, CapData, HeadphonesData, RunnersData, SocksData, ScarfData, GlovesData, BandanaData};          
             System.out.println(ItemTableArray[10][6]);
             
             if(ItemTableArray[10][6] != null){
                 Itemlists = Arrays.copyOf(ItemTableArray, ItemTableArray.length);
             }
	}
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();	
	} catch (Exception e){
                e.printStackTrace();
        }finally{
        
        }
	return Itemlists;	
		

	}
    public static void main(String[] args){

    };
}
