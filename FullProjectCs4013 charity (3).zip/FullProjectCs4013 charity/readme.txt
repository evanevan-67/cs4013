change location of file in (line 10) in Readcsv.java to the location where the file is saved


run mainOOP for the project